﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login_SSO : System.Web.UI.Page
{
    string name = string.Empty;
    string mobilenumber = string.Empty;
    string aadharnumber = string.Empty;
    string emailid = string.Empty;
   
    public static byte[] Signature = new byte[] { 0x53, 0x61, 0x6c, 0x74, 0x65, 0x64, 0x5f, 0x5f };
    DA_Authentication.DA_Authentication objDAAuth = new DA_Authentication.DA_Authentication();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Request.QueryString["token"] != null)
            {
                string SSO_tokenid = (Request.QueryString["token"] == null ? "" : Request.QueryString["token"]);
                HTTPRequestcall(SSO_tokenid);
            }
            else
            {
                Response.Redirect(Page.ResolveUrl("~/login.aspx"), false);
            }
        }
    }

    void HTTPRequestcall(string token)
    {
        try
        {
            using (var client = new HttpClient())
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12 | System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls;

                ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
                string secret_key = System.Web.Configuration.WebConfigurationManager.AppSettings["secret_key_SSO"];
                string service_id = System.Web.Configuration.WebConfigurationManager.AppSettings["service_id_SSO"];
                var postTask = new List<KeyValuePair<string, string>>();
                postTask.Add(new KeyValuePair<string, string>("token", token));
                postTask.Add(new KeyValuePair<string, string>("secret_key", secret_key));
                postTask.Add(new KeyValuePair<string, string>("service_id", service_id));
                HttpContent Content = new FormUrlEncodedContent(postTask);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                String CitizenSSO_ServiceURL = System.Web.Configuration.WebConfigurationManager.AppSettings["CitizenSSOUrl"];
                HttpResponseMessage response = client.PostAsync(CitizenSSO_ServiceURL, Content).Result;
                response.
                if (response != null)
                {
                    if (response.IsSuccessStatusCode)
                    {
                        var jsonString = response.Content.ReadAsStringAsync().Result;
                        var responsedata = (Newtonsoft.Json.Linq.JObject)JsonConvert.DeserializeObject(jsonString);
                        UserData userData = JsonConvert.DeserializeObject<UserData>(jsonString);
                        //name = userData.Name;
                        name = userData.Name == null ? string.Empty : userData.Name;
                        mobilenumber = userData.Mobile == null ? string.Empty : userData.Mobile;
                        aadharnumber = userData.aadhaarNumber == null ? string.Empty : userData.aadhaarNumber;
                        // Decrypt the Aadhaar number
                        string decryptedAadhaarNumber = Decrypt(aadharnumber, secret_key);
                        emailid = userData.Email == null ? string.Empty : userData.Email;
                        Gender = userData.Gender == null ? string.Empty : userData.Gender;
                        dob = userData.DateOfBirth == null ? string.Empty : userData.DateOfBirth;
                        fathername = userData.CareOf == null ? string.Empty : userData.CareOf;
                      
                       
                    }

                   
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, GetType(), Guid.NewGuid().ToString(), "alert('" + response.StatusCode + "');", true);
                    }
                }
            }
        }
        catch (AggregateException err)
        {
            string eror = "";
            foreach (var errInner in err.InnerExceptions)
            {
                eror = eror + "  ->" + errInner;
            }
        }
    }
    public static string Decrypt(string base64Cipher, string password)
    {
        using (Aes aes = Aes.Create())
        {
            byte[] saltedCipher = Convert.FromBase64String(base64Cipher);
            if (!Enumerable.SequenceEqual(Signature, saltedCipher.Take(Signature.Length)))
                return null; // invalid cipher

            byte[] salt = saltedCipher.Skip(Signature.Length).Take(8).ToArray();
            byte[] cipher = saltedCipher.Skip(Signature.Length + salt.Length).ToArray();

            byte[] passwordBytes = Encoding.Default.GetBytes(password);
            byte[] kdfOutput = EvpKDF(passwordBytes, salt, 48);

            aes.Key = kdfOutput.Take(32).ToArray();
            aes.IV = kdfOutput.Skip(32).Take(16).ToArray();

            using (ICryptoTransform aesDecryptor = aes.CreateDecryptor())
            {
                byte[] decrypted = aesDecryptor.TransformFinalBlock(cipher, 0, cipher.Length);
                return Encoding.UTF8.GetString(decrypted);
            }
        }
    }
    static byte[] EvpKDF(byte[] password, byte[] salt, int targetSize)
    {
        using (MD5 md5 = MD5.Create())
        {
            byte[] output = new byte[targetSize];
            byte[] buffer = null;
            int outputSize = 0;

            while (outputSize < targetSize)
            {
                if (buffer != null)
                    buffer = md5.ComputeHash(buffer.Concat(password).Concat(salt).ToArray());
                else
                    buffer = md5.ComputeHash(password.Concat(salt).ToArray());

                Array.Copy(buffer, 0, output, outputSize, buffer.Length);
                outputSize += buffer.Length;
            }

            return output;
        }
    }
   

    public class UserData
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("mobile")]
        public string Mobile { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("gender")]
        public string Gender { get; set; }

        [JsonProperty("dob")]
        public string DateOfBirth { get; set; }

        [JsonProperty("co")]
        public string CareOf { get; set; }

        [JsonProperty("street")]
        public string Street { get; set; }

        [JsonProperty("aadhaarNumber")]
        public string aadhaarNumber { get; set; }

        [JsonProperty("username")]
        public string username { get; set; }

        [JsonProperty("lm")]
        public string address1 { get; set; }

        [JsonProperty("loc")]
        public string address2 { get; set; }

        [JsonProperty("vtc")]
        public string city { get; set; }

        [JsonProperty("dist")]
        public string district { get; set; }

        [JsonProperty("state")]
        public string state { get; set; }

        [JsonProperty("pc")]
        public string pincode { get; set; }

        [JsonProperty("sso_id")]
        public string aadhaarvid { get; set; }
    }

}
