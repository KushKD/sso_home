﻿using AjaxControlToolkit;
using HPSSSBCERTIFICATE.Utility;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    GenricHelperClass.SQLHelper objSSSB = new GenricHelperClass.SQLHelper();
    DA_Authentication.DA_Authentication objDAAuth = new DA_Authentication.DA_Authentication();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                
                string currentUrl = HttpContext.Current.Request.Url.ToString();

                string url = HttpContext.Current.Request.Url.AbsoluteUri;

                if (!string.IsNullOrWhiteSpace(url))
                {
                    int urlManipulation = url.IndexOf("/?");
                    int sqlInjection = url.ToLower().IndexOf("query"); // USELESS
                                                                       // forms authentication is not used, (returnurl)
                    if (urlManipulation == -1 && sqlInjection == -1)
                    {
                        HttpContext.Current.Response.AddHeader("Cache-Control", "no-cache, no-store, must-revalidate");
                        HttpContext.Current.Response.AddHeader("Pragma", "no-cache");
                        HttpContext.Current.Response.AddHeader("Expires", "0");
                    }
                    else
                    {
                        Session.Clear();
                        Session.Abandon();
                        Response.Cookies.Add(new HttpCookie("ASP.NET_SessionId", ""));
                        Response.Redirect(Page.ResolveUrl("~//error.html"), false);
                        return;
                    }
                }

                if (Request.Cookies["ASP.NET_SessionId"] != null)
                {
                    Response.Cookies["ASP.NET_SessionId"].Value = string.Empty;
                    Response.Cookies["ASP.NET_SessionId"].Secure = true;
                    Response.Cookies["ASP.NET_SessionId"].HttpOnly = true;
                    Response.Cookies["ASP.NET_SessionId"].Expires = DateTime.Now.AddMonths(-20);
                }

                if (Request.Cookies["AuthToken"] != null)
                {
                    Response.Cookies["AuthToken"].Value = string.Empty;
                    Response.Cookies["AuthToken"].Secure = true;
                    Response.Cookies["AuthToken"].HttpOnly = true;
                    Response.Cookies["AuthToken"].Expires = DateTime.Now.AddMonths(-20);
                }
                if (Request.Cookies["__AntiXsrfToken"] != null)
                {
                    Response.Cookies["__AntiXsrfToken"].Value = string.Empty;
                    Response.Cookies["__AntiXsrfToken"].Secure = true;
                    Response.Cookies["__AntiXsrfToken"].HttpOnly = true;
                    Response.Cookies["__AntiXsrfToken"].Expires = DateTime.Now.AddMonths(-20);
                }

                CsrfHandler.CsrfHandler.Validate(this.Page, forgeryToken);

            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), Guid.NewGuid().ToString(), "alert('" + HPRCAUtility.CommonUtility.CleanExceptionMessage(ex.Message) + "');", true);
        }
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        try
        {
            if (!string.IsNullOrWhiteSpace(txtusername.Text) && !string.IsNullOrWhiteSpace(txtPassword.Text)
                && !string.IsNullOrWhiteSpace(txtCaptcha.Text))
            {
                if (ucCaptcha.Validate(txtCaptcha.Text.Trim()))
                {
                    DataTable dt = new DataTable();
                    dt = objDAAuth.AuthenticateUser(txtusername.Text);
                    if (dt.Rows.Count > 0)
                    {
                        if (string.Compare(txtPassword.Text.ToUpper(), Convert.ToString(dt.Rows[0]["Password"]).ToUpper()) == 0)
                        {
                            // Login History
                            objDAAuth.SaveUserLogin_History(Convert.ToString(dt.Rows[0]["userid"]), Convert.ToString(dt.Rows[0]["roleid"]), "S"); // Login History
                                                                                                                                                  //                                     Session["userid"] = Convert.ToString(dt.Rows[0]["UserID"]);
                            Session["RoleId"] = dt.Rows[0]["RoleId"].ToString();
                            Session["Role"] = dt.Rows[0]["RoleId"].ToString();
                            Session["EmailID"] = dt.Rows[0]["EmailID"].ToString();
                            Session["UName"] = dt.Rows[0]["UName"].ToString();
                            Session["UMobileNo"] = dt.Rows[0]["UMobileNo"].ToString();
                            Session["LoginUserInfo"] = dt.Rows[0]["LoginUserInfo"].ToString();
                            Session["Userid"] = dt.Rows[0]["UserID"].ToString();
                            Session["Photo"] = Page.ResolveUrl("~/assets/img/avatar_2x.png");
                            Session["aadhaar_sso"]= dt.Rows[0]["AadhaarNumber"].ToString();
                            Session["UserID"] = Convert.ToString(dt.Rows[0]["UserID"]);
                            Session["MaskedAadhaarNumber"] = Convert.ToString(dt.Rows[0]["AadhaarNumber"]);
                            switch (Convert.ToString(Session["RoleId"]))
                            {
                               
                                default:
                                    break;
                            }
                        }
                        else
                        {

                            objDAAuth.SaveUserLogin_History(Convert.ToString(dt.Rows[0]["userid"]), Convert.ToString(dt.Rows[0]["roleid"]), "U"); // Login History 
                            txtusername.Text = string.Empty;
                            txtPassword.Text = string.Empty;
                            txtCaptcha.Text = string.Empty;
                            ScriptManager.RegisterStartupScript(this, this.GetType(), Guid.NewGuid().ToString(), "alert('Invalid username and password.');", true);
                            return;
                        }
                    }
                    else
                    {
                        txtusername.Text = string.Empty;
                        txtPassword.Text = string.Empty;
                        txtCaptcha.Text = string.Empty;
                        ScriptManager.RegisterStartupScript(this, this.GetType(), Guid.NewGuid().ToString(), "alert('Invalid username and password.');", true);
                        return;

                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), Guid.NewGuid().ToString(), "alert('Please enter valid captcha.');", true);
                    txtusername.Text = string.Empty;
                    txtPassword.Text = string.Empty;
                    txtCaptcha.Text = string.Empty;
                    txtCaptcha.Focus(); return;
                }
            }
        }

        catch (Exception ex)
        {
            txtusername.Text = string.Empty;
            txtPassword.Text = string.Empty;
            txtCaptcha.Text = string.Empty;

        }
    }
}